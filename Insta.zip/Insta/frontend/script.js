var table_body = document.getElementById("table-body");
let addFormEl = document.getElementById("add-form");
let unameInput = document.getElementById("username-input");
let msgBox = document.getElementById("message-area");
let sortByDropdown = document.getElementById("sort-by");
let sortOrderDropdown = document.getElementById("sort-order");
let sortBtn = document.getElementById("sort-button");

// global variables
var profilesNow = [];
let refreshTimer;

// ------------------ MESSAGE BOX --------------------
// NOTE: this just shows success/error messages on top
function showMsg(txt, isError) {
    if (isError === undefined) isError = false;

    msgBox.textContent = txt;
    msgBox.className = "message";
    if (isError) {
        msgBox.classList.add("error");
    } else {
        msgBox.classList.add("success");
    }

   
    setTimeout(function(){
        msgBox.textContent = "";
        msgBox.className = "message";
    }, 5000);
}

// FORMAT NUMBERS
function formatNum(n) {
    if (n >= 1000000) {
        return (n/1000000).toFixed(2) + "M";
    } else if (n >= 1000) {
        return (n/1000).toFixed(1) + "K";
    } else {
        return n;
    }
}

// RENDER TABLE
function renderTableNow() {
    let sortBy = sortByDropdown.value;
    let order = sortOrderDropdown.value;

   
    let sorted = profilesNow.slice();

    for (let i=0; i<sorted.length; i++) {
        for (let j=i+1; j<sorted.length; j++) {
            let a = sorted[i][sortBy] || 0;
            let b = sorted[j][sortBy] || 0;
            if ((order==="asc" && a>b) || (order==="desc" && a<b)) {
                let tmp = sorted[i];
                sorted[i] = sorted[j];
                sorted[j] = tmp;
            }
        }
    }

    table_body.innerHTML = "";

    if (sorted.length === 0) {
        table_body.innerHTML = "<tr><td colspan='7'>No profiles lol. Add above.</td></tr>";
        return;
    }

    // loop over profiles
    for (let i=0; i<sorted.length; i++) {
        let profile = sorted[i];

        let row = document.createElement("tr");

       
        let linkStuff;
        if (profile.error) {
            linkStuff = "@" + profile.username + " <span style='color:red'>(error)</span>";
        } else {
            linkStuff = "<a href='https://instagram.com/" + profile.username + "' target='_blank'>@" + profile.username + "</a>";
        }

        row.innerHTML = `
            <td>${i+1}</td>
            <td>${linkStuff}</td>
            <td>${profile.error ? "N/A" : formatNum(profile.followers)}</td>
            <td>${profile.error ? "N/A" : formatNum(profile.following)}</td>
            <td>${profile.error ? "N/A" : profile.posts}</td>
            <td>${profile.error ? "N/A" : ("Followers: " + profile.followers + "<br>Following: " + profile.following)}</td>
            <td><button class="removeBtn" data-uname="${profile.username}">remove</button></td>
        `;
        table_body.appendChild(row);
    }

    let allBtns = document.querySelectorAll(".removeBtn");
    for (let b of allBtns) {
        b.addEventListener("click", function(ev){
            let uname = ev.currentTarget.dataset.uname;
            removeProfile(uname);
        });
    }
}

// ADD PROFILE
async function addProfile(ev) {
    ev.preventDefault();
    let uname = unameInput.value.trim();
    if (uname === "") {
        showMsg("username empty", true);
        return;
    }

    stopRefresh();

    let addBtn = addFormEl.querySelector("button");
    addBtn.disabled = true;
    addBtn.textContent = "Adding...";

    let tmpRow = document.createElement("tr");
    tmpRow.id = "row-" + uname;
    tmpRow.innerHTML = `<td>*</td><td>@${uname}</td><td colspan="5">loading data...</td>`;
    table_body.appendChild(tmpRow);

    setTimeout(async function(){
        try {
            let res = await fetch("/api/add", {
                method:"POST",
                headers: {"Content-Type":"application/json"},
                body: JSON.stringify({username: uname})
            });
            let result = await res.json();

            if (res.ok) {
                showMsg("added " + uname);
                unameInput.value = "";
                await updateDashboard();
            } else {
                throw new Error(result.msg || "add failed");
            }
        } catch (e) {
            console.error("error adding profile", e);
            showMsg("err: " + e.message, true);
            document.getElementById("row-" + uname).remove();
        } finally {
            addBtn.disabled = false;
            addBtn.textContent = "Add Profile";
            startRefresh();
        }
    }, 200);
}

// REMOVE PROFILE
async function removeProfile(uname) {
    stopRefresh();

    profilesNow = profilesNow.filter(function(p){
        return p.username.toLowerCase() !== uname.toLowerCase();
    });
    renderTableNow();
    showMsg("removing...");

    try {
        let res = await fetch("/api/remove/" + uname, {method:"POST"});
        let result = await res.json();
        if (res.ok) {
            showMsg(uname + " removed");
        } else {
            throw new Error(result.msg || "failed remove");
        }
    } catch (e) {
        showMsg("oops " + e.message, true);
        await updateDashboard();
    } finally {
        startRefresh();
    }
}

// FETCH DASHBOARD
async function updateDashboard() {
    try {
        let res = await fetch("/api/data");
        if (!res.ok) throw new Error("server down?");
        profilesNow = await res.json();
        renderTableNow();
    } catch (err) {
        console.log("update err", err);
        table_body.innerHTML = "<tr><td colspan='7'>error loading</td></tr>";
    }
}

// TIMER REFRESH
function stopRefresh() {
    clearInterval(refreshTimer);
}
function startRefresh() {
    stopRefresh();
    refreshTimer = setInterval(updateDashboard, 30000);
}

// INITIAL SETUP
addFormEl.addEventListener("submit", addProfile);
sortBtn.addEventListener("click", renderTableNow);
updateDashboard();
startRefresh();