from flask import Flask, render_template, jsonify, request
import json
import requests   

# Connecting with HTML,JS,CSS files
app = Flask(__name__, template_folder="html", static_folder="frontend")

dataFile = "data.json"   # Variable for storing table data

# HELPERS for READING/WRITING

def readDataFromJson():
    try:
        with open(dataFile, "r") as f:
            profiles = json.load(f)
            return profiles
    except:
        print("data file not found or broken, making new one...")
        defaults = [
            {"username": "nasa", "followers": 0, "following": 0, "posts": 0},
            {"username": "natgeo", "followers": 0, "following": 0, "posts": 0}
        ]
        saveDataToJson(defaults)
        return defaults

def saveDataToJson(profs):
    with open(dataFile, "w") as f:
        json.dump(profs, f, indent=2)   # adding indent so its readable

# API fetcher (i used Apify for insta)

def getProfileFromApi(uname):
    API_KEY = "apify_api_zFF6L6wtvWvNoa06midDGWtgpycs7c0i3k0f"
    url = f"https://api.apify.com/v2/acts/apify~instagram-profile-scraper/run-sync-get-dataset-items?token={API_KEY}"
   
    body = {"usernames": [uname]}
    headers = {"Content-Type": "application/json"}
   
    try:
        res = requests.post(url, json=body, headers=headers)
        data = res.json()
        if len(data) == 0:
            return {"username": uname, "error": "empty response"}
        first = data[0]
        return {
            "username": first.get("username", uname),
            "followers": first.get("followersCount", 0),
            "following": first.get("followsCount", 0),
            "posts": first.get("postsCount", 0),
            "error": None
        }
    except Exception as e:
        print("api error for", uname, ":", e)
        return {"username": uname, "error": str(e)}

# FLASK ROUTES

@app.route("/api/data")
def dashboardData():
    # read data first
    profs = readDataFromJson()
    results = []
    for p in profs:
        d = getProfileFromApi(p["username"])
        results.append(d)

    # sort by followers (descending)
    for i in range(len(results)):
        for j in range(i+1, len(results)):
            if results[j].get("followers", 0) > results[i].get("followers", 0):
                results[i], results[j] = results[j], results[i]

    return jsonify(results)

@app.route("/api/add", methods=["POST"])
def addProfile():
    body = request.json
    uname = body.get("username")
    if uname is None or uname.strip() == "":
        return jsonify({"success": False, "msg": "pls give username"}), 400
   
    profs = readDataFromJson()

    # check if already exists
    for p in profs:
        if p["username"].lower() == uname.lower():
            return jsonify({"success": False, "msg": uname+" already exists"}), 409

    # fetch new profile data
    newdata = getProfileFromApi(uname)
    if newdata.get("error") != None:
        return jsonify({"success": False, "msg": newdata["error"]}), 400

    profs.append(newdata)
    saveDataToJson(profs)

    return jsonify({"success": True, "msg": uname+" added"})

@app.route("/api/remove/<uname>", methods=["POST"])
def removeProfile(uname):
    profs = readDataFromJson()
    if len(profs) <= 1:
        return jsonify({"success": False, "msg": "cant remove last one"}), 400

    updated = []
    found = False
    for p in profs:
        if p["username"].lower() != uname.lower():
            updated.append(p)
        else:
            found = True

    if not found:
        return jsonify({"success": False, "msg": "profile not found"}), 404
   
    saveDataToJson(updated)
    return jsonify({"success": True, "msg": uname+" removed"})

@app.route("/")
def index():
    return render_template("main.html")

# MAIN PROGRAM STARTER
if __name__ == "__main__":
    print(">>> running backend now...")   # debug msg
    app.run(debug=True, port=5000)   # hardcoding port just in case